public class programm
{
    public static Main main;

    public programm()
    {}
    public static void main(String[] args) {
        main = new Main();
    }
}